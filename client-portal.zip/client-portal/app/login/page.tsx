"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const supabase = createClient();
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    setLoading(false);
    if (error) {
      setError(error.message);
    } else {
      setSent(true);
    }
  };

  return (
    <div
      style={{
        display: "flex",
        minHeight: "100vh",
        alignItems: "center",
        justifyContent: "center",
        padding: 24,
      }}
    >
      <div
        style={{
          background: "white",
          padding: 40,
          borderRadius: 12,
          boxShadow: "0 4px 24px rgba(0,0,0,0.06)",
          width: "100%",
          maxWidth: 380,
        }}
      >
        <h1 style={{ fontSize: 22, marginBottom: 8, color: "#1F3864" }}>
          Client Portal
        </h1>
        <p style={{ color: "#666", fontSize: 14, marginBottom: 24 }}>
          Enter your email and we'll send you a secure sign-in link.
        </p>

        {sent ? (
          <p style={{ color: "#1E7145", fontSize: 14 }}>
            Check your inbox — click the link we just sent to {email} to sign in.
          </p>
        ) : (
          <form onSubmit={handleSubmit}>
            <input
              type="email"
              required
              placeholder="you@company.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={{
                width: "100%",
                padding: "10px 12px",
                borderRadius: 8,
                border: "1px solid #ddd",
                marginBottom: 12,
                fontSize: 14,
                boxSizing: "border-box",
              }}
            />
            <button
              type="submit"
              disabled={loading}
              style={{
                width: "100%",
                padding: "10px 12px",
                borderRadius: 8,
                border: "none",
                background: "#1F3864",
                color: "white",
                fontSize: 14,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              {loading ? "Sending..." : "Send sign-in link"}
            </button>
            {error && (
              <p style={{ color: "#B3261E", fontSize: 13, marginTop: 10 }}>
                {error}
              </p>
            )}
          </form>
        )}
      </div>
    </div>
  );
}
